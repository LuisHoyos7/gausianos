@extends('layouts.app')

@section('content')
    customer.show template
@endsection