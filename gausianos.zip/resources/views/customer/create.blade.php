@extends('layouts.app')

@section('content')
    customer.create template
@endsection