@extends('layouts.app')

@section('content')
    customer.edit template
@endsection