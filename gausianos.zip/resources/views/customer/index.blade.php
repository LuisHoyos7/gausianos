@extends('layouts.app')

@section('content')
    customer.index template
@endsection