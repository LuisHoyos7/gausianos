@extends('layouts.app')

@section('content')
    @include('serviceCourse.form')
@endsection