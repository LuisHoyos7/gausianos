@extends('layouts.app')

@section('content')
    @include('workType.form')
@endsection