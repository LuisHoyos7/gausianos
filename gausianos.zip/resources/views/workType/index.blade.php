@extends('layouts.app')

@section('content')
    @include('layouts.flash-message')
    @include('workType.table')
@endsection

