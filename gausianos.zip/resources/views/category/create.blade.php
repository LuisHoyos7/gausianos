@extends('layouts.app')

@section('content')
    @include('category.form')
@endsection