@extends('layouts.app')

@section('content')
    @include('course.form')
@endsection