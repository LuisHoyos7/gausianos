@extends('layouts.app')

@section('content')
    image.create template
@endsection