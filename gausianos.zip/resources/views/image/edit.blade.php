@extends('layouts.app')

@section('content')
    image.edit template
@endsection