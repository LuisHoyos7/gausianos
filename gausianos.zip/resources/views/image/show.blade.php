@extends('layouts.app')

@section('content')
    image.show template
@endsection