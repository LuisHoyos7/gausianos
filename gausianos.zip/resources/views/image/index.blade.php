@extends('layouts.app')

@section('content')
    image.index template
@endsection