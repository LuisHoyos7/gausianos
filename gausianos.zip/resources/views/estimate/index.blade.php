@extends('layouts.app')

@section('content')
    @include('layouts.flash-message')
    @include('estimate.table')
@endsection

