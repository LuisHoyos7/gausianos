@extends('layouts.app')

@section('content')
    @include('serviceType.form')
@endsection