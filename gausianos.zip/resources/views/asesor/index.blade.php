@extends('layouts.app')

@section('content')
    @include('layouts.flash-message')
    @include('asesor.table')
@endsection

