@extends('layouts.app')

@section('content')
    @include('asesor.form')
@endsection