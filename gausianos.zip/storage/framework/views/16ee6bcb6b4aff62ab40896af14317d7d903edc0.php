
<?php if(empty($course)): ?>
<?php echo Form::open(['route' => 'course.store']); ?>

<?php else: ?>
<?php echo Form::model($course, ['route' => ['course.update', $course->id], 'method' => 'PUT']); ?>

<?php endif; ?>
<div class="card card-custom gutter-b example example-compact">
	<div class="card-header">
		<h3 class="card-title">
			Agregar Cursos
		</h3>
  </div>
  <div class="card-body">
		<div class="form-group form-group-last">
      <div class="row">
        <div class="col-md-6">
          <?php echo e(Form::label('Nombre asignatura')); ?>

          <?php echo e(Form::text('name', null, ['class'  => 'form-control', 'placeholder' => 'Ingesa el nombre del curso'])); ?>

        </div>
        <div class="col-md-6">
          <?php echo e(Form::label('Elija Una Categoria')); ?>

          <?php echo e(Form::select('category_id',$category, null, ['class'  => 'form-control'])); ?>

        </div>
      </div>
    </div>
  </div>
  <div class="card-footer">
		<button type="submit" class="btn btn-primary mr-2">Guardar</button>
		<button type="reset" class="btn btn-secondary">Cancelar</button>
	</div>
</div>

<?php echo Form::close(); ?>




<?php /**PATH C:\laragon\www\gausianos\resources\views/course/form.blade.php ENDPATH**/ ?>