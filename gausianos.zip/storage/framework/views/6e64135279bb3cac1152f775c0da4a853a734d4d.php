
<?php if(empty($serviceCourse)): ?>
<?php echo Form::open(['route' => 'service-course.store']); ?>

<?php else: ?>
<?php echo Form::model($serviceCourse, ['route' => ['service-course.update', $serviceCourse->id], 'method' => 'PUT']); ?>

<?php endif; ?>
<div class="card card-custom gutter-b example example-compact">
	<div class="card-header">
		<h3 class="card-title">
			Servicios ofrecidos por Asignaturas
		</h3>
  </div>
  <div class="card-body">
		<div class="form-group form-group-last">
      <div class="row">
        <div class="col-md-6">
          <?php echo e(Form::label('Elija Una Asignatura')); ?>

          <?php echo e(Form::select('course_id',$course, null, ['class'  => 'form-control'])); ?>

        </div>
        <div class="col-md-6">
          <?php echo e(Form::label('Elija Un Servicio  ofertado por esta Asignatura')); ?>

          <?php echo e(Form::select('service_type_id',$serviceType, null, ['class'  => 'form-control', 'id' => 'servicios'])); ?>

        </div>

        <!-- este campo se llena mediante js con el nombre del servicio  -->
        <input hidden type="text" name="name" id="name">
      </div>
    </div>
  </div>
  <div class="card-footer">
		<button type="submit" class="btn btn-primary mr-2">Guardar</button>
		<button type="reset" class="btn btn-secondary">Cancelar</button>
	</div>
</div>
<?php echo Form::close(); ?><?php /**PATH C:\laragon\www\gausianos\resources\views/serviceCourse/form.blade.php ENDPATH**/ ?>